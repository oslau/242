##This function creates an S3 method to plot of class "Grid"		##
##Inputs: a matrix of type "Grid".									##
##Output: plots the grid as an image.								##

plot.Grid = function(x, y, ...){
	rows = nrow(x)
	image(t(x[rows:1,]), axes = FALSE, col = c("white", "blue", "red"), ...)
	}
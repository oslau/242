######################################################################
##This function generates a grid of red and blue cars				##
##Inputs: number of rows (grid.r), number of columns (grid.c),		##
##	proportion of grid filled with cars (rho)						##
##Output: a grid.r by grid.c matrix randomly filled with 0, 1, 2's	##
##	where the 1 = blue, 2 = red. Note that the proportion of 1's and##
##	2's are 1:1.													##
######################################################################

genGrid = function(grid.r, grid.c, rho = .5){
	if(rho > 1 | rho < 0){
		cat("Warning: This is not a valid proportion (rho). \n Proceeding with default rho = 0.5. \n")
		rho = 0.5
	}
	if(rho == 0){
		cat("Cool, you made an empty parking lot...\n\n")
	}
	if(rho == 1){
		cat("Looks like LA rush hour. \n\n")
	}
	
	###SIMPLE CALCS###
	ncars = round(rho * grid.r * grid.c, 0)	##total number of cars
	totcells = grid.r * grid.c	##total number of cells
	
	###GENERATE GRID###
	colors = c(rep(0, totcells-ncars), rep(1, round(ncars/2)), rep(2, round(ncars/2)))
	grid = matrix(sample(colors, totcells), nrow = grid.r)
	class(grid) = "Grid"
	return(grid)
}

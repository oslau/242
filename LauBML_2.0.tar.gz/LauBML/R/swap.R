swap = function(car.pos, potential, grid){
	matrix(.C('swap', as.integer(nrow(car.pos)), as.integer(car.pos[,1]), as.integer(car.pos[,2]), as.integer(potential[,1]), as.integer(potential[,2]), as.integer(nrow(grid)), myGrid = as.double(grid))$myGrid, nrow(grid), ncol(grid))
}

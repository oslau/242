######################################################################
##This function simply changes the (x, y) coordinate to move up.	##
##	Also checks if next space is out of the grid. If it is, it 		##
##	loops to the other side. 										##
##Inputs: a matrix of x, y coordinates to be moved up. Also the 	##	
##	number of rows in the grid, for checking if out of the grid 	##
##Output: a matrix of x, y coordinates moved up one row.			##
######################################################################

next.pos = function(ij, n.row){
	up = cbind((ij[,1]-1), ij[,2])	##change coords
	up[up[ , 1] == 0, 1] = n.row	##check coords
	return(up)						##return coords
}
######################################################################
##This function simulates traffic movement for a given grid, from 	##
##	time = 1 until user specified time = t.						 	##
##Inputs: a given grid (grid) and time (t)							##
##Output: Creates a .gif of the movement from time 1 through t in 	##
##	current directory titled "myMovie.gif", plots grid at time t, 	##
##	and returns a vector of velocities at each time point			##
######################################################################

simTraffic = function(grid, t = 100, plotLast = TRUE){
	velocity = integer(t)
	for(i in 1:t){
		new.grid = move(grid, i)
		velocity[i] = length(grid) - sum(new.grid == grid)
		grid = new.grid
		class(grid) = "Grid"
		if(i > 5){
			if(all(velocity[(i - 5):i] == 0)){
			cat("No movement for 5 time periods. \n Stopping now at time = ", i, "\n\n")
			break}
		}
	}
	if(plotLast == TRUE){
		plot(grid)}
	return(velocity)
}

######################################################################
##This function creates an S3 method to print the summary of an 	##
##	object of class "Grid"											##
##Inputs: a matrix of type "Grid".									##
##Output: prints the current state, dimensions, total number of 	##
##	spaces, number of blue cars, number of red cars, number of open	##
##	spaces.															##
######################################################################

summary.Grid = function(object, ...){
	cat("Current grid state:\n")
	print(object)
	cat("Grid dimensions:", dim(object), "\n")
	cat("Total number of spaces", length(object), "\n")
	cat("Number of blue cars:", sum(object==1), "\n")
	cat("Number of red cars:", sum(object==2), "\n")
	cat("Number of open spaces:", sum(object==0), "\n")
}
######################################################################
##This function moves the colored cars according to time and thereby##
##	color. Red uses the same functions as Blue, only on a transposed##
##	version of the grid. 											##
##Inputs: original grid, and time									##
##Output: returns given grid with moved cars at time.				##
######################################################################

move = function(grid, time){
	d = dim(grid)
	if(time %% 2 == 0){		##red cars
		grid = t(grid[ , ncol(grid):1])
		car.pos = which(grid == 2, arr.ind = TRUE)
		potential = next.pos(car.pos, nrow(grid))
		new.grid = swap(car.pos, potential, grid)
		new.grid = t(new.grid[nrow(new.grid):1,])
	}
	else{		##blue cars
		car.pos = which(grid == 1, arr.ind = TRUE)
		potential = next.pos(car.pos, nrow(grid))
		new.grid = swap(car.pos, potential, grid)
	}
	return(new.grid)
}
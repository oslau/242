void swap(int *len, int *currX, int *currY,
            int *nextX, int *nextY,
            int *M, double *grid);
